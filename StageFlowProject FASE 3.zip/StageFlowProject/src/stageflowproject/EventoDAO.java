package stageflowproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EventoDAO {

    public boolean registrarEvento(String nombre, String descripcion, String fecha, String lugar, String categoria) {
        String sql = "INSERT INTO eventos (nombre, descripcion, fecha, lugar, categoria) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, nombre);
            stmt.setString(2, descripcion);
            stmt.setString(3, fecha);
            stmt.setString(4, lugar);
            stmt.setString(5, categoria);

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.out.println("Error en CREATE: " + e.getMessage());
            return false;
        }
    }

    public void obtenerEventos() {
        String sql = "SELECT * FROM eventos";
        
        try (Connection conn = ConexionBD.obtenerConexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            System.out.println("\n--- LISTA DE EVENTOS EN LA BASE DE DATOS ---");
            boolean hayRegistros = false;
            
            while (rs.next()) {
                hayRegistros = true;
                int id = rs.getInt("id_evento");
                String nombre = rs.getString("nombre");
                String fecha = rs.getString("fecha");
                String lugar = rs.getString("lugar");
                
                System.out.println("ID: " + id + " | Nombre: " + nombre + " | Fecha: " + fecha + " | Lugar: " + lugar);
            }
            
            if (!hayRegistros) {
                System.out.println("No hay eventos registrados actualmente.");
            }
            
        } catch (SQLException e) {
            System.out.println("Error en el READ: " + e.getMessage());
        }
    }

    public boolean actualizarEvento(int idEvento, String nombre, String descripcion, String fecha, String lugar, String categoria) {
        String sql = "UPDATE eventos SET nombre = ?, descripcion = ?, fecha = ?, lugar = ?, categoria = ? WHERE id_evento = ?";
        
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, nombre);
            stmt.setString(2, descripcion);
            stmt.setString(3, fecha);
            stmt.setString(4, lugar);
            stmt.setString(5, categoria);
            stmt.setInt(6, idEvento);

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.out.println("Error en el UPDATE: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEvento(int idEvento) {
        String sql = "DELETE FROM eventos WHERE id_evento = ?";
        
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idEvento);

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.out.println("Error en el DELETE: " + e.getMessage());
            return false;
        }
    }
}