package stageflowproject;

public class StageFlowProject {

    public static void main(String[] args) {
        EventoDAO eventoDao = new EventoDAO();

        System.out.println("=== PROBANDO FLUJO CRUD COMPLETO ===");

     
        System.out.println("\n--- 1. PRUEBA CREATE ---");
        boolean insertado = eventoDao.registrarEvento(
            "Concierto de Rock ARIABELA 2026",
            "Gran concierto de cierre de gira",
            "2026-12-15",
            "Arena Cayala Ciudad Guatemala",
            "Música"
        );
        if (insertado) {
            System.out.println("Evento insertado correctamente.");
        }

        System.out.println("\n--- 2. PRUEBA READ ---");
        eventoDao.obtenerEventos();

        System.out.println("\n--- 3. PRUEBA UPDATE ---");
        boolean actualizado = eventoDao.actualizarEvento(
            1, 
            "Concierto de Rock ARIABELA 2026 (reprogramacion)", 
            "Fecha Oficial Reprogramada", 
            "2026-12-20", 
            "Parque de la Industria", 
            "Música Rock"
        );
        if (actualizado) {
            System.out.println("Evento actualizado correctamente.");
        } else {
            System.out.println("No se pudo actualizar el evento.");
        }

        System.out.println("\n--- READ TRAS UPDATE ---");
        eventoDao.obtenerEventos();

        System.out.println("\n--- 4. PREUBA DELETE ---");
        boolean eliminado = eventoDao.eliminarEvento(2);
        if (eliminado) {
            System.out.println("Evento eliminado correctamente.");
        } else {
            System.out.println("ℹ Nota: El ID 2 no existía para eliminar.");
        }

        System.out.println("\n--- LISTA FINAL DE EVENTOS ---");
        eventoDao.obtenerEventos();
    }
}