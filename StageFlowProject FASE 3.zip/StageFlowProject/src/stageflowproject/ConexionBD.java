package stageflowproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    private static final String URL = "jdbc:mysql://localhost:3306/eventpass_db?useSSL=false&serverTimezone=UTC";
    private static final String USUARIO = "root";
    private static final String CONTRASENA = "";

    public static Connection obtenerConexion() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
        } catch (ClassNotFoundException e) {
            System.out.println("Error: No se encontró el Driver de MySQL en las Librerias: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error al conectar a la Base de Datos (EL XAMPP TIENE QUE ESTAR ENCENDIDO): " + e.getMessage());
        }
        return conn;
    }
}