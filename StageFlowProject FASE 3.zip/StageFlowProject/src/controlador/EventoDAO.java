package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class EventoDAO {


    public boolean registrarEvento(String nombre, String fecha, String lugar) {
        String sql = "INSERT INTO eventos (nombre, fecha, lugar, descripcion, categoria) VALUES (?, ?, ?, '', 'General')";
        try (Connection con = stageflowproject.ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, nombre);
            ps.setString(2, fecha);
            ps.setString(3, lugar);
            ps.executeUpdate();
            return true;
            
        } catch (Exception e) {
            System.out.println("Error al registrar evento: " + e.getMessage());
            return false;
        }
    }


    public void cargarEventos(DefaultTableModel modelo) {
        modelo.setRowCount(0);
        String sql = "SELECT * FROM eventos";
        try (Connection con = stageflowproject.ConexionBD.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id_evento"),
                    rs.getString("nombre"),
                    rs.getString("fecha"),
                    rs.getString("lugar")
                };
                modelo.addRow(fila);
            }
        } catch (Exception e) {
            System.out.println("Error al cargar eventos: " + e.getMessage());
        }
    }
}