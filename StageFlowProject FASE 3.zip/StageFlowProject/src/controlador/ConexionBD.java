package controlador;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConexionBD {
    public static Connection obtenerConexion() {
        Connection conn = null;
        Properties props = new Properties();
        try (InputStream input = ConexionBD.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null) {
        
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/eventpass_db?useSSL=false&serverTimezone=UTC", "root", "");
                return conn;
            }
            props.load(input);
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                props.getProperty("db.url"),
                props.getProperty("db.user"),
                props.getProperty("db.password")
            );
        } catch (Exception e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return conn;
    }
}